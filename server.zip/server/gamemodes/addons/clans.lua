print('loading addon: clans.lua')
AClans = {} 
--Clans list
AClans.Clans = {
    ['testclan'] = {
        ['ronnyevans'] = {
          fullaccess = true,
          lvl = 5
        }
    },
    ['omg'] = {}
}

--customs
AClans.isPlayerInClan = function(playerid,clanname)
  local nickname = getPlayerName(playerid)
  return AClans.Clans[clanname][nickname] or false 
end

--clan command
AClans.clan_commands = {
}

AClans.hooks = {}
print('clans.lua: loaded!')