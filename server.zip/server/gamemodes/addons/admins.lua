print('loading addon: admins.lua')
AAdmins = {} 
--admin list
AAdmins.admins_list = {
    ['ronnyevans'] = {
      fullaccess = true,
      lvl = 5
    }
}

--customs
AAdmins.isPlayerAdmin = function(playerid)
  local nickname = getPlayerName(playerid)
  return AAdmins.admins_list[nickname] or false 
end

--admins command
AAdmins.admin_commands = {
    ['a'] = {
      lvl = 1,
      desc = '�������� ��������� � �����-���',
      func = function(playerid,args)
        local msg = table.concat(args, " ", 2, #args)
        if #msg > 0 then 
          for admin_nick, admin_data in pairs(AAdmins.admins_list) do
            local admin_id = getPlayerIdByName(admin_nick)
            if admin_id then
              sendClientMessage(admin_id, ('[A] %s(%d): %s'):format(getPlayerName(playerid),playerid,msg), 0x28B463)
            end
          end
        else
          sendClientMessage(playerid, '(������) {ffffff}��������� /a [message]', 0xCD0000)
        end
      end
    }
}

AAdmins.hooks = {}
AAdmins.hooks.commands = function(playerid,args) -- type(args) == table 
    if AAdmins.admin_commands[args[1]] then
        local acommand = AAdmins.admin_commands[args[1]]
        local adata = AAdmins.isPlayerAdmin(playerid)
        if adata then
            if adata.lvl >= acommand.lvl then
                acommand.func(playerid,args)
            end
        else
            sendClientMessage(playerid,('{CD0000}(������) {ffffff}������� �������� � %d LVL!'):format(acommand.lvl),0xCD0000)
        end
        return true
    end
end
AAdmins.hooks.chat = function(playerid,msg)

end
print('admins.lua: loaded')