-- custom functions
print('load server customs functions')
--get id by name
function getPlayerIdByName(name)
    for i = 1, #SPool.sPlayers do
      if SPool.sPlayers[i].nickname == name then
        return SPool.sPlayers[i].playerid
      end
    end
    return false
end
print('sc.lua: custom functions loaded!')